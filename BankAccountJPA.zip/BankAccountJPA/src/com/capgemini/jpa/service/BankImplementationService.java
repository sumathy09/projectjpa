 package com.capgemini.jpa.service;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.jpa.dao.BankImplementationDao;
import com.capgemini.jpa.dao.BankInterfaceDao;
import com.capgemini.jpa.entity.Customer;
import com.capgemini.jpa.exception.CustomerException;

public class BankImplementationService implements BankInterfaceService {
    Scanner sc = new Scanner(System.in);

    BankInterfaceDao dao = new BankImplementationDao();
    //Customer cu= new Customer();

    @Override
    public Customer createAccount(Customer cust)throws CustomerException {
        return dao.createAccount(cust);
    }

    @Override
    public double showBalance(int accNo)throws CustomerException {
        return dao.showBalance(accNo);
    }

    @Override
    public double deposit(int accNo, double deposit)throws CustomerException {
        return dao.deposit(accNo, deposit);
    }

    @Override
    public double withdraw(int accNo, double withdraw)throws CustomerException {
        return dao.withdraw(accNo, withdraw);
    }

    @Override
    public double fundTransfer(int ida, int idb, double transfer)throws CustomerException {
        return dao.fundTransfer(ida, idb, transfer);

    }

    @Override
    public String printTransactions(long id)throws CustomerException {
        return dao.printTransactions(id);

    }

    public boolean isValidName(String name) {

        Pattern p = Pattern.compile("[A-Za-z]{3,25}");
        Matcher mat = p.matcher(name);
        boolean s = mat.find();
        if (!s) {
            System.out.println("Name starts with captital");
        }
        return s;
    }

    public boolean isValidPhone(String phoneNo) {
        Pattern p = Pattern.compile("[0-9][0-9]{9}");
        Matcher mat = p.matcher(phoneNo);
        boolean s = mat.find();
        if (!s) {
            System.out.println("Enter 10 digits");
        }
        return s;
    }

    public boolean isValidAathar(String aathar) {
        Pattern p = Pattern.compile("[0-9]{12}");
        Matcher mat = p.matcher(aathar);
        boolean s = mat.find();
        if (!s) {
            System.out.println("Enter 12 digits");
        }
        return s;
    }

    public int validAccount(int id)throws CustomerException {
        return dao.validAccount(id);
    }
    
}