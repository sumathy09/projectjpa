package com.capgemini.jpa.dao;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import com.capgemini.jpa.entity.Customer;
import com.capgemini.jpa.entity.Transaction;
import com.capgemini.jpa.exception.CustomerException;
import com.capgemini.jpa.utility.JPAUtil;

public class BankImplementationDao implements BankInterfaceDao {
	// long accNo;
	Customer c = new Customer();
	Transaction t=new Transaction();
	double balance;
	int equal = 0;
	EntityManager entityManager = null;
	@Override
	public Customer createAccount(Customer cust) throws CustomerException {
		try {
			entityManager = JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			entityManager.persist(cust);
			entityManager.getTransaction().commit();
			return cust;
		} catch (PersistenceException e) {
			e.printStackTrace();
			throw new CustomerException(e.getMessage());
		} finally {
			entityManager.close();
		}
	}

	@Override
	public double showBalance(int accNo) throws CustomerException {

		try {
			entityManager = JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			c = entityManager.find(Customer.class, accNo);
			balance = c.getBalance();
			entityManager.getTransaction().commit();

		} catch (PersistenceException e) {
			e.printStackTrace();
			throw new CustomerException(e.getMessage());
		} finally {
			entityManager.close();
		}
		return balance;
	}

	@Override
	public double deposit(int accNo, double deposit) throws CustomerException {
		//EntityManager entityManager1= null;
		try {
			entityManager = JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			c = entityManager.find(Customer.class, accNo);
			balance = c.getBalance();
			balance = balance + deposit; 
			c.setBalance(balance);
			
			Transaction trans=new Transaction();
			//c.CustomerTransaction(trans);
			trans.setTransType("deposit");
			trans.setTransHistory(deposit);
			trans.setCus(c);
			entityManager.merge(c);
			entityManager.persist(trans);
			entityManager.getTransaction().commit();
			return balance;
		} catch (PersistenceException e) {
			e.printStackTrace();
			throw new CustomerException(e.getMessage());
		} finally {
			entityManager.close();

		}
	}

	@Override
	public double withdraw(int accNo, double withdraw) throws CustomerException {
		try {
			entityManager = JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			c = entityManager.find(Customer.class, accNo);
			
			balance = c.getBalance();
			balance = balance - withdraw;
			
			c.setBalance(balance);
			Transaction tran=new Transaction();
			//c.CustomerTransaction(trans);
			tran.setTransType("withdraw");
			tran.setTransHistory(withdraw);
			tran.setCus(c);
			entityManager.merge(c); 
			entityManager.persist(tran);
			
			entityManager.getTransaction().commit();
			return balance;
		} catch (PersistenceException e) {
			e.printStackTrace();
			throw new CustomerException(e.getMessage());
		} finally {
			entityManager.close();
		}

	}

	@Override
	public double fundTransfer(int ida, int idb, double transfer)
			throws CustomerException {
		return balance;
	}

	 
	@Override
	public List<Transaction> printTransactions(int id) throws CustomerException
		{
			
		entityManager = JPAUtil.getEntityManager();
		entityManager.getTransaction().begin();
			List<Transaction> pt = new ArrayList<Transaction>();
			Query query = entityManager.createNativeQuery("select * from print_transaction where accNo = ?",Transaction.class);
			query.setParameter(1,id);
			pt = query.getResultList();
			return pt;
			
		
	}

	public int validAccount(int id) throws CustomerException {
		try{
			entityManager = JPAUtil.getEntityManager();
		
		entityManager.getTransaction().begin();
		if((entityManager.find(Customer.class, id))!=null)
			 equal=id;
		entityManager.getTransaction().commit();
		return equal;
		}catch (PersistenceException e) {
			e.printStackTrace();
			throw new CustomerException(e.getMessage());
		} finally {
			entityManager.close();
		}
		
		

	}
}
