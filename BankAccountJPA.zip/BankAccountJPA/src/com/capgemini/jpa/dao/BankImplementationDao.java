package com.capgemini.jpa.dao;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;

import com.capgemini.jpa.entity.Customer;
//import com.capgemini.jpa.entity.Employee;
import com.capgemini.jpa.exception.CustomerException;
//import com.capgemini.jpa.entity.Employee;
//import com.capgemini.jpa.exception.EmployeeException;
import com.capgemini.jpa.utility.JPAUtil;

public class BankImplementationDao implements BankInterfaceDao {

	//long accNo;
	Customer c = new Customer();
	double balance;
	int equal = 0;
	EntityManager entityManager = null;
	//Map<Long, Customer> map = new HashMap<Long, Customer>();

	@Override
	public Customer createAccount(Customer cust) throws CustomerException {

		try {
			// EntityManager entityManager=null;
			entityManager = JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			entityManager.persist(cust);
			entityManager.getTransaction().commit();
			return cust;
		} catch (PersistenceException e) {
			e.printStackTrace();
			throw new CustomerException(e.getMessage());
		} finally {
			entityManager.close();
		}

	}

	@Override
	public double showBalance(int accNo) throws CustomerException {

		try {
			entityManager = JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			c=entityManager.find(Customer.class,accNo);
			balance = c.getBalance();
			entityManager.getTransaction().commit();
			
		} catch (PersistenceException e) {
			e.printStackTrace();
			throw new CustomerException(e.getMessage());
		} finally {
			entityManager.close();
		}
		return balance;
	}

	@Override
	public double deposit(int accNo, double deposit) throws CustomerException {
		try {
			entityManager = JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			String tran = "";
			//c = map.get(id);
			
			c=entityManager.find(Customer.class,accNo);
			balance = c.getBalance();
			tran = "Money Deposited-" + deposit + "";
			balance = balance + deposit;
			tran = tran + "\n" + "Updated Balance-" + balance + "\n";
			c.CustomerTransaction(tran);
			c.setBalance(balance);
			entityManager.merge(c);
			//map.put(id, c);
			entityManager.getTransaction().commit();
			return balance;
		} catch (PersistenceException e) {
			e.printStackTrace();
			throw new CustomerException(e.getMessage());
		} finally {
			entityManager.close();
		}
	}

	@Override
	public double withdraw(int accNo, double withdraw) throws CustomerException {
		try {
			entityManager = JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			c=entityManager.find(Customer.class,accNo);
		String tran = "";
		//c = map.get(id);
		tran = "Amount Withdrawn-" + withdraw + "";
			//entityManager.remove(c);
			balance = c.getBalance();
		balance = balance - withdraw;
		tran = tran + "\n" + "Balance After Withdrawl-" + balance + "\n";
		c.CustomerTransaction(tran);
		c.setBalance(balance);
		entityManager.merge(c);
		//map.put(id, c);
		// Customer e = maps.put(id, c);
		entityManager.getTransaction().commit();
		return balance;
		}catch (PersistenceException e) {
			e.printStackTrace();
			throw new CustomerException(e.getMessage());
		} finally {
			entityManager.close();
		}

	}

	@Override
	public double fundTransfer(int ida, int idb, double transfer)
			throws CustomerException {
		return balance;
	}

	@Override
	public String printTransactions(long id) throws CustomerException {
		String tran = "";
		//c= map.get(id);
		entityManager = JPAUtil.getEntityManager();
		entityManager.getTransaction().begin();

		tran = c.getTransHistory();
		tran += "\n" + "Current Balance--" + "\n" + c.getBalance();
		entityManager.getTransaction().commit();
		return tran;
	}

	public int validAccount(int id) throws CustomerException {
		//c = entityManager.find(Customer.class, id);
		if (entityManager.contains(id))
			equal = id;
		return equal;

	}
}
