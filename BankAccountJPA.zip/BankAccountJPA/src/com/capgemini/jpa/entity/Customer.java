package com.capgemini.jpa.entity;

//import java.util.Calendar;

import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
import javax.persistence.Id;
//import javax.persistence.Temporal;
//import javax.persistence.TemporalType;

@Entity
public class Customer {
	@Id
	private int accNo;
	//@GeneratedValue(strategy=GenerationType.IDENTITY)
	private String name;
	private String phoneNo;
	private String address;
	private String aathar;
	
	private double balance;
	private String transHistory;

	 
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAathar() {
		return aathar;
	}

	public void setAathar(String aathar) {
		this.aathar = aathar;
	}

	public int getAccNo() {
		return accNo;
	}

	public void setAccNo(int accNo2) {
		this.accNo = accNo2;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getTransHistory() {
		return transHistory;
	}

	public String setTransHistory(String transHistory) {
		this.transHistory = transHistory;
		return transHistory;
	}

	@Override
	public String toString() {
		return "Customer [name=" + name + ", phoneNo=" + phoneNo + ", address="
				+ address + ", aathar=" + aathar + ", balance=" + balance + "]"
				+ "\n";
	}

	public String CustomerTransaction(String tran) {
		if (this.getTransHistory() == null)
			this.setTransHistory("");
		return this.setTransHistory(this.getTransHistory() + tran);
	}

	

}



 